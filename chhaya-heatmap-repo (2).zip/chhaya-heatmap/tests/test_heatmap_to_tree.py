"""Unit tests for the HeatMap-to-Tree pipeline. Run with: pytest"""
import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import heatmap_to_tree as h  # noqa: E402


@pytest.fixture(scope="module")
def city():
    h.RNG = np.random.default_rng(0)  # deterministic synthetic city
    return h.make_synthetic_city()


@pytest.fixture(scope="module")
def planned(city):
    model = h.train_model(city)
    return h.simulate_cooling(city, model)


def test_city_has_expected_shape_and_columns(city):
    assert len(city) == h.GRID ** 2
    for col in ["row", "col", "ndvi", "built_up", "water_index",
                "population", "lst", "is_water"]:
        assert col in city.columns


def test_city_values_are_in_valid_ranges(city):
    assert city["ndvi"].between(0, 1).all()
    assert city["built_up"].between(0, 1).all()
    assert (city["population"] >= 0).all()
    assert (city.loc[city["is_water"], "population"] == 0).all()


def test_model_learns_temperature_pattern(city):
    model = h.train_model(city)
    pred = model.predict(city[h.FEATURES])
    ss_res = ((city["lst"] - pred) ** 2).sum()
    ss_tot = ((city["lst"] - city["lst"].mean()) ** 2).sum()
    assert 1 - ss_res / ss_tot > 0.9


def test_cooling_is_never_negative(planned):
    assert (planned["cooling_c"] >= 0).all()


def test_already_green_pixels_get_no_cooling(planned):
    green = planned[planned["ndvi"] >= h.TARGET_NDVI]
    assert len(green) > 0
    assert (green["cooling_c"] == 0).all()


def test_picks_respect_budget_spacing_and_rules(planned):
    picks = h.pick_sites(planned, n_pick=20, spacing=3)
    assert 0 < len(picks) <= 20
    assert not picks["is_water"].any()
    assert (picks["ndvi"] < 0.3).all()
    assert list(picks["rank"]) == list(range(1, len(picks) + 1))
    assert picks["score"].is_monotonic_decreasing
    coords = list(zip(picks["row"], picks["col"]))
    for i, a in enumerate(coords):
        for b in coords[i + 1:]:
            assert max(abs(a[0] - b[0]), abs(a[1] - b[1])) >= 3


def test_pick_sites_rejects_invalid_inputs(planned):
    with pytest.raises(ValueError):
        h.pick_sites(planned, n_pick=0)
    with pytest.raises(ValueError):
        h.pick_sites(planned, spacing=0)


def test_center_pixel_maps_to_city_center():
    lat, lon = h.to_latlon(30, 30, (60, 60))
    assert lat == pytest.approx(h.CENTER_LAT)
    assert lon == pytest.approx(h.CENTER_LON)


def test_save_outputs_writes_csv_and_image(planned, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    picks = h.pick_sites(planned, n_pick=10, spacing=3)
    h.save_outputs(planned, picks, (h.GRID, h.GRID))
    assert (tmp_path / "heatmap_to_tree_overview.png").exists()
    out = pd.read_csv(tmp_path / "planting_sites.csv")
    assert len(out) == len(picks)
    assert {"rank", "lat", "lon", "cooling_c"} <= set(out.columns)
