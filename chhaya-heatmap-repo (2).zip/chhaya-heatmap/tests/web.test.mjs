// Tests for the web prototype (heatmap-to-tree.html). Run with: node --test tests/
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const html = fs.readFileSync(path.join(here, "..", "heatmap-to-tree.html"), "utf8");
const script = html.match(/<script>([\s\S]*)<\/script>/)[1];

// Minimal fake DOM, enough to run the page's script and read what it writes.
function loadPage() {
  const els = {};
  const make = (id) => ({
    id, style: {}, textContent: "", innerHTML: "", checked: true,
    value: id === "sp" ? "3" : "40", dataset: {}, hidden: false, _l: {},
    addEventListener(type, fn) { this._l[type] = fn; },
    setAttribute() {},
    getBoundingClientRect() { return { left: 0, top: 0, width: 480, height: 480 }; },
  });
  const ctx = new Proxy({}, { get: () => () => {}, set: () => true });
  const document = {
    getElementById: (id) => els[id] || (els[id] = make(id)),
    querySelectorAll: () => [],
  };
  els.map = Object.assign(make("map"), { getContext: () => ctx });
  vm.runInNewContext(script, { document, window: {}, Promise, Math });
  return els;
}

test("page renders a plan with the full tree budget", () => {
  const els = loadPage();
  assert.equal(els.s3.textContent, "21,000 kg/year"); // 40 sites x 25 trees x 21 kg
  assert.match(els.s6.textContent, /^\d+ of 40$/);
  assert.match(els.s5.textContent, /^\d+ of \d+$/);
});

test("regression model fits the simulated temperatures well", () => {
  const els = loadPage();
  assert.ok(parseFloat(els.s4.textContent) > 0.9);
});

test("changing the budget slider updates the plan", () => {
  const els = loadPage();
  els.n.value = "10";
  els.n._l.input();
  assert.equal(els.s3.textContent, "5,250 kg/year"); // 10 sites
  assert.match(els.s6.textContent, /^\d+ of 10$/);
});

test("turning clean-air mode off is reflected in the results", () => {
  const els = loadPage();
  els.ca.checked = false;
  els.ca._l.input();
  assert.equal(els.s6.textContent, "off");
});

test("zone report has a caption and column headers", () => {
  const els = loadPage();
  assert.ok(els.zones.innerHTML.includes("<caption"));
  assert.ok(els.zones.innerHTML.includes('scope="col"'));
});

test("arrow keys move through map pixels and announce them", () => {
  const els = loadPage();
  let prevented = 0;
  els.map._l.keydown({ key: "ArrowRight", preventDefault() { prevented++; } });
  els.map._l.keydown({ key: "ArrowDown", preventDefault() { prevented++; } });
  assert.match(els.info.textContent, /^(Pixel \(1, 1\)|River pixel)/);
  els.map._l.keydown({ key: "Tab", preventDefault() { prevented++; } });
  assert.equal(prevented, 2); // Tab keeps its normal behaviour
});

test("accessibility basics are present in the markup", () => {
  assert.match(html, /<html lang="en">/);
  assert.match(html, /class="skip"/);
  assert.match(html, /<canvas[^>]*tabindex="0"[^>]*aria-label=/);
  assert.match(html, /id="info" aria-live="polite"/);
  for (const id of ["n", "sp", "eq", "cp", "ca"]) {
    assert.ok(html.includes(`id="${id}"`), `control ${id} exists`);
  }
  assert.match(html, /<label for="n">/);
  assert.match(html, /<label for="sp">/);
});

test("page contains no secrets or remote scripts", () => {
  assert.doesNotMatch(html, /api[_-]?key|secret|password|token/i);
  assert.doesNotMatch(html, /<script[^>]+src=/i);
});
