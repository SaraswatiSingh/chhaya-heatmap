# Security notes

- The web prototype is a static page: no accounts, no server, no secrets, and no data sent anywhere except an optional Claude request when a viewer presses the brief button.
- The repository contains no API keys or credentials. `.gitignore` blocks common credential files. If you add Google Earth Engine, authenticate with `ee.Authenticate()` in your own session and never commit tokens or service-account keys.
- Dependencies are version-bounded in `requirements.txt`.
- All numbers shown come from simulated data and documented assumptions, and should not be used for real planning decisions without validation.

To report a problem, open a GitHub issue.
